package com.example.myfinalproject.CallBacks;

import com.example.myfinalproject.DataModels.Profession;

public interface ProfessionClickListener {
    void onProfessionClick(Profession profession);
}
