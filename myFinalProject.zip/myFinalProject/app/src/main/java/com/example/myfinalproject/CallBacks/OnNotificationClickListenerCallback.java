package com.example.myfinalproject.CallBacks;

import com.example.myfinalproject.DataModels.NotificationAdmin;

public interface OnNotificationClickListenerCallback {

        void onNotificationClick(NotificationAdmin notification);

}
