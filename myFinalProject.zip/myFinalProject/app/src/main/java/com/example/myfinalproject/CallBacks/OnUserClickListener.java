package com.example.myfinalproject.CallBacks;

public interface OnUserClickListener {
    void onUserClick(int position);
}
