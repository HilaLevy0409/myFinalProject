package com.example.myfinalproject.CallBacks;

import com.example.myfinalproject.DataModels.NotificationAdmin;

public interface OnNotificationClickListener {

        void onNotificationClick(NotificationAdmin notification);

}
