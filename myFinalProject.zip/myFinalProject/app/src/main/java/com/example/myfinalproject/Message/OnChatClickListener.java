package com.example.myfinalproject.Message;

public interface OnChatClickListener {
    void onChatSelected(String userId, String userName);
}

