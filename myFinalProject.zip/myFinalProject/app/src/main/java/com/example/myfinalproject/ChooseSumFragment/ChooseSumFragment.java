package com.example.myfinalproject.ChooseSumFragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.myfinalproject.Database.SummaryDatabase;
import com.example.myfinalproject.Models.Summary;
import com.example.myfinalproject.R;
import com.example.myfinalproject.WritingSumFragment.SummaryPresenter;
import com.example.myfinalproject.WritingSumFragment.WritingSumFragment;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Calendar;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ChooseSumFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ChooseSumFragment extends Fragment implements View.OnClickListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private Button btnAdd;

    private static final String IMAGE_DIRECTORY = "/demonuts";
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_STORAGE_PERMISSION = 101;
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_IMAGE_GALLERY = 2;
    private static final String AUTHORITY = "com.example.firestorepicapplication.fileprovider";
    private int GALLERY = 1, CAMERA = 2;


   SummaryPresenter summaryPresenter;
    Button btnPress;
    private Button btnChoose,btnUpload;
    private ImageView imageSum;
    private ImageView imgFirebase;
    private Uri filePath;
    private final int PICK_IMAGE_REQUEST = 71;
    FirebaseStorage storage;
    StorageReference storageReference;


    private ListView listViewSummaries;
    private SummaryAdapter SumAdapter;
    private List<Summary> sumList;

    public ChooseSumFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ChooseSumFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ChooseSumFragment newInstance(String param1, String param2) {
        ChooseSumFragment fragment = new ChooseSumFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


        setContentView(R.layout.onerow_summary);
        summaryPresnter = new SummaryPresnter(this);
        btnPress=findViewById(R.id.btnPress);
        btnPress.setOnClickListener(this);
        btnChoose = (Button) findViewById(R.id.btnChoose);
        btnUpload = (Button) findViewById(R.id.btnUpload);
        imageView = (ImageView) findViewById(R.id.imgView);
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        requestCameraPermission();
        requestStoragePermission();
        imgFirebase = (ImageView) findViewById(R.id.imgFirebase);
        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog();
            }
        });


        btnChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //uploadImage();
            }
        });


        listViewSummaries = findViewById(R.id.listViewSummaries);
        summaryList = new ArrayList<>();
        summaryAdapter = new SummaryAdapter(this, summaryList);
        listViewSummaries.setAdapter(SummaryAdapter);
        loadProducts();




        listViewSummaries.setOnItemClickListener((parent, view, position, id) -> {
            Summary selectedSummary = summaryList.get(position);
            showManagementDialog(selectedSummary);
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_choose_sum, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        btnAdd = view.findViewById(R.id. btnAdd);
        btnAdd.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == btnAdd) {
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.flFragment, new WritingSumFragment())
                    .commit();
        }
        if (view == btnPress) {
            EditText etClass = findViewById(R.id.etClass);
            EditText etProfession = findViewById(R.id.etProfession);
            EditText etSummaryTitle = findViewById(R.id.etSummaryTitle);


            // Convert image to Base64 string instead of byte array
            String base64Image = imageViewToBase64(imageSum);


            Summary summary = new Summary(
                    "",
                    etSummary.getText().toString(),
                    Integer.parseInt(etAmountProd.getText().toString()),
                    base64Image
            );
            summaryPresenter.submitClicked(summary);
        }

    }



    private void showEditDialog(Summary summary) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_product, null);


        EditText etClass = dialogView.findViewById(R.id.etClass);
        EditText etProfession = dialogView.findViewById(R.id.etProfession);
        EditText etSummaryTitle = dialogView.findViewById(R.id.etSummaryTitle);
        ImageView imgSum = dialogView.findViewById(R.id.imageSum);
        Button btnChangeImage = dialogView.findViewById(R.id.btnChangeImage);


        etName.setText(product.getProdName());
        etAmount.setText(String.valueOf(product.getProdAmount()));
        loadBase64Image(product.getProdPic(), imgProduct);


        btnChangeImage.setOnClickListener(v -> {
            // Store the current ImageView reference for later use
            imageView = imgSum;
            showPictureDialog();
        });


        builder.setView(dialogView)
                .setPositiveButton("שמור", (dialog, which) -> {
                    summary.setProdName(etName.getText().toString());
                    summary.setProdAmount(Integer.parseInt(etAmount.getText().toString()));
                    if (imgSum.getDrawable() != null) {
                        summary.setImage(imageViewToBase64(imgSum));
                    }
                    summaryPresenter.updateSummary(summary);
                })
                .setNegativeButton("ביטול", (dialog, which) -> dialog.cancel());


        builder.show();
    }


    private void showDeleteConfirmationDialog(Summary summary) {
        new AlertDialog.Builder(getContext())
                .setTitle("מחיקת ")
                .setMessage("האם ברצונך למחוק זה?")
                .setPositiveButton("כן", (dialog, which) ->
                        summaryPresenter.deleteSummary(summary.getSummaryId()))
                .setNegativeButton("לא", null)
                .show();
    }


    public void onSummatyUpdated(Summary summary) {
        Toast.makeText(getContext(), "המוצר עודכן בהצלחה", Toast.LENGTH_SHORT).show();
        loadProducts();
    }


    public void onSummaryDeleted() {
        Toast.makeText(getContext(), "נמחק בהצלחה", Toast.LENGTH_SHORT).show();
        loadProducts();
    }


    public void onError(String message) {
        Toast.makeText(getContext(), "שגיאה: " + message, Toast.LENGTH_SHORT).show();
    }




    private void showManagementDialog(Summary summary) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("ניהול ");
        String[] options = {"עריכה", "מחיקה", "ביטול"};


        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0: // Edit
                    showEditDialog(summary);
                    break;
                case 1: // Delete
                    showDeleteConfirmationDialog(summary);
                    break;
                case 2: // Cancel
                    dialog.dismiss();
                    break;
            }
        });


        builder.show();
    }




    private void loadProducts() {
        summaryPresenter.loadSummaries(new SummaryDatabase().SummariesCallback() {
            @Override
            public void onSuccess(List<Summary> summaries) {
                summaryList.clear();
                summaryList.addAll(summaries);
                summaryAdapter.notifyDataSetChanged();
            }


            @Override
            public void onError(String message) {
                Toast.makeText(ProductActivity.this, "Error loading products: " + message,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void requestStoragePermission() {
    }
    private void launchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getContext().getPackageManager()) != null) {
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                // Error occurred while creating the File
                ex.printStackTrace();
            }
            // Continue only if the File was successfully created
            Uri photoURI = FileProvider.getUriForFile(getContext(), "com.example.firestorepicapplication.fileprovider", photoFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }
    private File createImageFile() throws IOException {
        // Create an image file name
        String imageFileName = "JPEG_" + System.currentTimeMillis() + ".jpg";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        return image;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with camera launch
                launchCamera();
            } else {
                // Permission denied, handle the error
                Toast.makeText(getContext(), "Camera permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void requestCameraPermission() {
        if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        }
    }


    public void onSuccess(Summary summary) {
        Toast.makeText(this, summary.getProdName() + " added", Toast.LENGTH_SHORT).show();
    }


    private void showPictureDialog(){
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(getContext());
        pictureDialog.setTitle("נא לבחור מאיפה להוסיף תמונה:");
        String[] pictureDialogItems = {
                "מהגלריה",
                "מהמצלמה" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }


    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);


        startActivityForResult(galleryIntent, GALLERY);
    }


    private void takePhotoFromCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {


        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContext().getContentResolver(), contentURI);
                    String path = saveImage(bitmap);
                    Toast.makeText(getContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
                    imageSum.setImageBitmap(bitmap);


                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(getContext(), "Failed!", Toast.LENGTH_SHORT).show();
                }
            }


        }
        if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
            imageSum.setImageBitmap(thumbnail);
            saveImage(thumbnail);
            Toast.makeText(getContext(), "Image Saved!", Toast.LENGTH_SHORT).show();


        }
    }


    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }


        try {
            File f = new File(wallpaperDirectory, MessageFormat.format("{0}.jpg", Calendar.getInstance().getTimeInMillis()));
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(getContext(),
                    new String[]{f.getPath()},
                    new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::--->" + f.getAbsolutePath());


            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }


    //Convert imageView to byte[]
    private byte[] imageViewToByte(ImageView image) {
        Bitmap bitmap=((BitmapDrawable)image.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 0, stream);
        byte[]byteArray=stream.toByteArray();
        return byteArray;
    }
    private void chooseImage() {


    }



    private String imageViewToBase64(ImageView image) {
        try {
            Bitmap bitmap = ((BitmapDrawable)image.getDrawable()).getBitmap();
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream); // Use 70% quality for better storage
            byte[] byteArray = stream.toByteArray();
            return Base64.encodeToString(byteArray, Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    // Add method to load Base64 image into ImageView
    private void loadBase64Image(String base64Image, ImageView imageView) {
        try {
            byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            imageView.setImageBitmap(decodedByte);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}