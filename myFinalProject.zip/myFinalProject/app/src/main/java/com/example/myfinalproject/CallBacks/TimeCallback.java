package com.example.myfinalproject.CallBacks;

public interface TimeCallback {
    void onTimerUpdate(long millisUntilFinished);
    void onTimerFinish();
}