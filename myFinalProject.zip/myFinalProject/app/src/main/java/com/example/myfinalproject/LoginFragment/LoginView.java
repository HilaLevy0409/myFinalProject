package com.example.myfinalproject.LoginFragment;

public interface LoginView {
    void showLoginSuccess();
    void showLoginFailure(String error);
}
