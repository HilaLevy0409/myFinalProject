package com.example.myfinalproject.RegistrationFragment;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterUserPresenter {

    RegistrationFragment view;
    private FirebaseAuth mAuth;


    public RegisterUserPresenter(RegistrationFragment view) {

        this.view = view;
        mAuth = FirebaseAuth.getInstance();

    }

    public void submitClicked(User user) {


        mAuth.createUserWithEmailAndPassword("", "");
    }


}

