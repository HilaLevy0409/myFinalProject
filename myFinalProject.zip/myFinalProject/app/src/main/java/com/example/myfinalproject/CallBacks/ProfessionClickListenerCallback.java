package com.example.myfinalproject.CallBacks;

import com.example.myfinalproject.DataModels.Profession;

public interface ProfessionClickListenerCallback {
    void onProfessionClick(Profession profession);
}
