package com.example.myfinalproject.WritingSumFragment;

public class SummaryPresenter {
}
